"""Backward-compatible public API for the super agent."""
from .services.super_agent import TradeThesis, synthesize

__all__ = ["TradeThesis", "synthesize"]
