"""Backward-compatible public API for position sizing."""
from .services.position_sizer import SizingResult, size_position

__all__ = ["SizingResult", "size_position"]
