import pytest

from trader.core.config import RiskConfig, TraderConfig, validate_runtime_config
from trader.engine.orchestrator import Orchestrator
from trader.core.state_machine import State


def test_kill_switch_config_starts_halted(tmp_path):
    orch = Orchestrator(
        RiskConfig(kill_switch=True),
        TraderConfig(mode="paper", db_path=str(tmp_path / "ks.db")),
    )
    assert orch.is_halted()
    assert orch.sm.state == State.HALTED


def test_on_silence_wait_never_executes(tmp_path):
    tc = TraderConfig(mode="paper", on_silence="wait", db_path=str(tmp_path / "wait.db"))
    orch = Orchestrator(RiskConfig(), tc, user_veto_hook=lambda order: "SILENCE")
    result = orch.run_cycle()
    assert result.execution is None
    assert result.veto is not None
    assert result.veto.response == "WAIT"


def test_live_mode_is_fail_closed(monkeypatch):
    monkeypatch.delenv("TRADER_LIVE_ACK", raising=False)
    with pytest.raises(RuntimeError):
        validate_runtime_config(TraderConfig(mode="live"))


def test_invalid_runtime_config_rejected():
    with pytest.raises(ValueError):
        validate_runtime_config(TraderConfig(mode="paper", on_silence="maybe"))
