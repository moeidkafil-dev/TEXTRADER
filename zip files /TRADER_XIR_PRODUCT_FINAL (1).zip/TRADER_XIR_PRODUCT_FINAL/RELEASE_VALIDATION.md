# TRADER / XIR — Final Stress Validation Report

Validation date: 2026-09-25  
Runtime: Python 3.13.5  
Release status: **stress-tested / paper & backtest validated / live fail-closed**

## Test summary

| Layer | Workload | Result |
|---|---:|---|
| Full automated suite | 71 tests | **71 passed** |
| Compile validation | Entire Python tree | **PASS** |
| End-to-end runtime stress | 3,000 cycles | **0 errors; 3,000/3,000 returned IDLE** |
| Risk-engine randomized tests | 100,000 cases | **PASS** |
| Execution-guard randomized tests | 50,000 cases | **PASS** |
| Schema serialization cases | 50,000 cases | **PASS** |
| State-machine exhaustive matrix | 286 state/transition pairs | **PASS** |
| Scenario matrix | 500+ targeted scenarios | **PASS** |
| Paper runtime | 100 cycles | **0 errors; 59 fills** |
| Backtest runtime | 500 bars | **0 errors; 460 fills** |
| Single end-to-end demo | Full pipeline | **PASS** |
| Coverage | 2,181 statements | **79%** |

Total explicit randomized/exhaustive checks above: **200,286**, plus **3,000 end-to-end cycles** and targeted scenario coverage.

## Defects found during stress validation

### 1. RE-EVALUATE state corruption — fixed
The previous release moved the state machine to `READING` and then recursively invoked the public cycle entry point, which expects `IDLE`. This could leave the runtime in `READING` after a RE-EVALUATE path.

Fix: internal cycle recursion now explicitly supports a `start_from_reading` path. Regression coverage verifies the RE-EVALUATE cap and final `IDLE` state.

### 2. Kill-switch race at final execution boundary — fixed
The previous execution path checked the kill switch in `ExecutionGuard`, then called the broker later. A kill switch activation between those points could reach the final tool.

Fix: `FinalTools` now performs a second fail-closed kill-switch check immediately before broker submission. A regression test simulates activation after Guard approval and verifies that the broker is not called.

## Benchmark

Measured on the validation runtime:

- State-machine exhaustive checks: ~1.2M transitions/s
- Risk engine randomized checks: ~60.8K checks/s
- Execution guard randomized checks: ~170.7K checks/s
- Schema roundtrip checks: ~90.6K/s
- End-to-end runtime benchmark: ~169 cycles/s for a 1,000-cycle isolated run
- 3,000-cycle persistence stress: ~87.6 cycles/s, with SQLite persistence and full audit/observability workload

## Runtime integrity observations

- No cycle in the 3,000-cycle stress run ended in an error state.
- No orphan orders were found in the stress database.
- All stress cycles returned to `IDLE`.
- Risk results contained the expected 11 deterministic rules per evaluated order.
- Paper and backtest executions completed without runtime errors.
- Kill-switch startup, resume, and execution-boundary race scenarios passed.
- Veto responses `OK`, `SILENCE`, `REJECT`, and `STOP` were exercised.
- `on_silence=wait` was exercised and produced no execution.
- RE-EVALUATE cap was exercised repeatedly and returned cleanly to `IDLE`.

## Environment note

`pip check` reports an unrelated environment-level dependency conflict: installed `moviepy 2.2.1` requires `pillow<12.0,>=9.2.0`, while the environment contains Pillow 12.3.0. This dependency is not used by TRADER/XIR and does not affect the project's 71-test suite or runtime benchmarks.

## Important release boundary

This validation establishes software/runtime robustness for the included deterministic mock, paper, and backtest paths. It does **not** prove that a live broker, exchange API, network, credentials, market-data feed, or third-party LLM integration will have zero failures, and it does not establish profitability.

The included live mode remains fail-closed until its explicit requirements are satisfied.
