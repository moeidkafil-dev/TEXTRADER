# Product Scope — TRADER/XIR 1.0.0

This release contains the canonical runtime implementation and its test suite.

Implemented product capabilities:
- multi-agent decision chain (Agent 1/2/3)
- context/data pipeline
- deterministic risk engine with 11 rules
- decision validation
- user veto/silence handling
- execution guard
- kill switch with fail-closed behavior
- state machine and runtime invariants I1–I5
- paper broker and backtest runtime
- SQLite storage and 28 logical memory types
- audit/observability paths
- CLI demo/paper/backtest commands
- automated regression and adversarial tests

Not included as a live service:
- exchange API credentials
- a production exchange-specific live broker implementation
- hosted web UI
- external notification credentials

Those are environment/integration deliverables rather than something that can be safely fabricated inside a generic release archive.
