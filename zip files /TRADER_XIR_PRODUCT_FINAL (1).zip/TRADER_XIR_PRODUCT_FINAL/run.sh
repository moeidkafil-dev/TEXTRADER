#!/usr/bin/env bash
set -euo pipefail
case "${1:-demo}" in
  demo) python -m trader.scripts.run_demo ;;
  paper) shift; python -m trader.scripts.run_paper "$@" ;;
  backtest) shift; python -m trader.scripts.run_backtest "$@" ;;
  test) python -m pytest -q ;;
  *) echo "Usage: $0 {demo|paper|backtest|test} [args...]"; exit 2 ;;
esac
