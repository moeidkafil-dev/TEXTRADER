# TRADER/XIR Product Installation

## Requirements
- Python 3.10+ (3.12 recommended)
- pip

## Install
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\\Scripts\\activate
python -m pip install --upgrade pip
python -m pip install -e .
```

## Verify
```bash
pytest -q
python -m trader.scripts.run_demo
python -m trader.scripts.run_paper --cycles 20
python -m trader.scripts.run_backtest --bars 200
```

## Modes
- `paper`: safe simulated execution (default)
- `backtest`: historical replay
- `live`: intentionally fail-closed until a supported live broker adapter and explicit live authorization are configured.

The package does not ship broker credentials and does not enable real-money execution by default.
